# Lista usando laço for
print(" ")
print("Lista de Lojas")
print(" ")

lojas = ["São Paulo", "Santos", "Palmeiras", "Corinthians"]

# Listar usando laço
for loja in lojas:
    print(loja)