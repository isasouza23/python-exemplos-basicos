# Var
palavra = "praia"

# Frase Original 
print(f"Quero ir para {palavra}")

# Substituta
nova_palavra = palavra.replace("praia", "sítio")

# Nova Frase
print(f"Quero ir para {nova_palavra}")