# Var
comprimento = 10
largura = 30

# Calculo
resultado = comprimento * largura 

# Saida
print(f"O perímetro do terreno é: {resultado} metros²")