# variavel
mensagem = "Ontem eu estava estudando Python"

# Uso do metodo split
lista_mensagem = mensagem.split(' ')

# Exibir
print(lista_mensagem[4])