# Importes
import math

# Valor do raio
r = 5  

# Calcula o perímetro da circunferência
perimetro = 2 * math.pi * r

# Exibe o resultado
print(f"O perímetro da circunferência com raio {r} cm é {perimetro:.2f} cm")