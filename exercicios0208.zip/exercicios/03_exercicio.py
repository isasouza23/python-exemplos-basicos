# Entrada
print("Informe os valores para a conversão\n")
valorDolar = float(input("Informe o valor em dolares: "))


# Calculo
conv = valorDolar*0.50

# Exibe Resultados
print(" O resultado da conversão é: {}.\n".format(conv))