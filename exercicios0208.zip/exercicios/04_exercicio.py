# Entrada
print("insira o valor das notas:")
n1 = float(input("Informe a 1° nota: "))
n2 = float(input("Informe a 2° nota: "))
n3 = float(input("Informe a 3° nota: "))
n4 = float(input("Informe a 4° nota: "))

# Calculo Media
media = (n1+n2+n3+n4)/4

# Saida
print(f"A media deste aluno é de: {media}")